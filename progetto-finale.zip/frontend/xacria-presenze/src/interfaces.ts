export interface UserCreds {
  name?: string;
  surname?: string;
  serial_num?: string;
  duty?: string;
  employment_type?: string;
  hire_date?: string;
  email: string;
  iban?: string;
  birth_date?: string;
  address?: string;
  phone?: string;
  password: string;
}
