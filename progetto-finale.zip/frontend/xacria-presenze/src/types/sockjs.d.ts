declare module 'sockjs-client/dist/sockjs.min.js';
