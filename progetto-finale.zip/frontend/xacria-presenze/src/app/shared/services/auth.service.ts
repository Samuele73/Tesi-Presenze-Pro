import { Injectable } from '@angular/core';
import { BehaviorSubject, throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, tap } from 'rxjs/operators';
import {
  LoginRequestDto,
  NewPasswordDto,
  SignInRequestDto,
  User,
  UserEmailResponse,
  UserService,
} from 'src/generated-client';

import { jwtDecode } from 'jwt-decode';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private _isLoggedIn$ = new BehaviorSubject<boolean>(false);
  $ = this._isLoggedIn$.asObservable();
  private readonly TOKEN_NAME: string = 'tkn';
  private userEmail: string = '';

  constructor(private userService: UserService, private router: Router) {
    /* this.checkUserAutentication(this.token); se si hanno problemi controlla*/

  }

  get token() {
    return sessionStorage.getItem(this.TOKEN_NAME);
  }
  set token(value: string | null) {
    if (value) {
      sessionStorage.setItem(this.TOKEN_NAME, value);
    } else {
      sessionStorage.removeItem(this.TOKEN_NAME);
    }
  }
  get email() {
    return this.userEmail;
  }
  set email(email: string) {
    this.userEmail = email;
  }

/*   setUserEmail() {
    if (this.token)
      this.userService.getEmailFromTkn(this.token).subscribe({
        next: (email: UserEmailResponse) => {
          const fetchedEmail: string | undefined = email.email;
          if (fetchedEmail) this.userEmail = fetchedEmail;
        },
      });
  } */

  checkUserAutentication(token: string | null): void {
    /* this._isLoggedIn$.next(false); */
    let isTokenValid: boolean = false;
    console.log('Token from ls:', this.token, this._isLoggedIn$);
    if (token) {
      console.log('ci sono');
      this.userService.validToken(this.token!!).subscribe({
        next: (resp: any) => {
          this._isLoggedIn$.next(true);
        },
        error: (err: any) => {
          console.error('Error from user tkn validation');
          this._isLoggedIn$.next(false);
          this.router.navigate(['login']);
        },
      });
      //aggiornare user role
    }
    /* this._isLoggedIn$.next(isTokenValid); */
  }

  //Metodo corretto per l'autenticazione
  checkUserAutentication2() {
    if (this.token) {
      return this.userService.validToken(this.token!!);
      //aggiornare user role
    }
    return;
  }

  getUserRole(): string | null {
    const token = this.token;
    if (!token) return null;
    const decoded: any = jwtDecode(token);
    return decoded.role;
  }

  isAdmin(): boolean {
    console.log('User role: ', this.getUserRole());
    return this.getUserRole() === 'ADMIN';
  }

  isOwner(): boolean {
    return this.getUserRole() === 'OWNER';
  }

  isPrivilegedUser(): boolean {
    return this.isAdmin() || this.isOwner();
  }

  getUserEmail() {
    const tkn = this.token;
    if (tkn) {
      return this.userService.getEmailFromTkn(tkn);
    }
    return false;
  }

  login(userCredentials: LoginRequestDto) {
    return this.userService.login(userCredentials).pipe(
      tap((resp: any) => {
        console.log('Login TAP: ', resp);
        if (resp) {
          this.token = resp.token;
          this._isLoggedIn$.next(true);
          //Estrarre user role da token;
        }
      })
    );
  }

  signin(userCredentials: SignInRequestDto) {
    return this.userService
      .signIn(userCredentials)
      .pipe(catchError(this.handleSigninError));
  }

  private handleSigninError(err: HttpErrorResponse) {
    if (err.status === 0) {
      console.error('Client side or Network error occurred:', err.error);
    } else if (err.status === 409) {
      console.error('Email already exists:', err);
      return throwError(() => new Error('Email già esistente'));
    } else {
      console.error('Server side error occurred:', err.error);
    }
    return throwError(
      () => new Error('Errore con la registrazione dell utente')
    );
  }

  changePassword(email: string) {
    return this.userService.resetPassword(email);
  }

  updatePassword(newPasswordRequest: NewPasswordDto) {
    return this.userService.saveNewPassword(newPasswordRequest);
  }

  getMyUserProfile() {
    return this.userService.getMyUserProfile();
  }

  updateCreds(user_creds: User) {
    return this.userService.updateUserProfile(user_creds);
  }
}
