export type Username = {
  name: string,
  surname: string
} | null;
