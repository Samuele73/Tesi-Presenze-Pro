
export interface ModalComponent{
  open(): void;
}
