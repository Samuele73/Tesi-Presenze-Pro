package com.tesi.presenzepro.calendar.exception;

public class InsufficientHoursException extends RuntimeException {
    public InsufficientHoursException(String message) {
        super(message);
    }
}
