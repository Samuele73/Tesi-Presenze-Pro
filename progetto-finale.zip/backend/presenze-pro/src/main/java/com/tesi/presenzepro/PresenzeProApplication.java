package com.tesi.presenzepro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PresenzeProApplication {

	public static void main(String[] args) {
		SpringApplication.run(PresenzeProApplication.class, args);
	}

}
