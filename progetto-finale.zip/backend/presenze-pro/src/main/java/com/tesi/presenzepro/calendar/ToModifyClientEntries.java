package com.tesi.presenzepro.calendar;

public record ToModifyClientEntries(

) {
}
