package com.tesi.presenzepro.user.model;

public enum Role {
    USER,
    ADMIN,
    OWNER
}
