package com.tesi.presenzepro.user.dto;

public record NewPasswordDto(
        String password,
        String token
) {
}
