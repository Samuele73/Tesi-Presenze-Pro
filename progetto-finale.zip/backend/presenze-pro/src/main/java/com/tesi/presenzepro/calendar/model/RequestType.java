package com.tesi.presenzepro.calendar.model;

public enum RequestType {
    FERIE,
    MALATTIA,
    TRASFERTA,
    PERMESSI,
    CONGEDO
}
