package com.tesi.presenzepro.project.repository;

public interface ProjectRepositoryCustom {
    boolean removeUserFromAllProjects(String email);
}
