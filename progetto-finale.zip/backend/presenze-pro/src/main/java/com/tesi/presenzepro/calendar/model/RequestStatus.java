package com.tesi.presenzepro.calendar.model;

public enum RequestStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}
