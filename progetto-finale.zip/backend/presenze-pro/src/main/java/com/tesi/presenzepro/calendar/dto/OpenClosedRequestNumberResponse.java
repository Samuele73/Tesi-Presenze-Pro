package com.tesi.presenzepro.calendar.dto;

public record OpenClosedRequestNumberResponse(
        Integer OPEN,
        Integer CLOSED
) {
}
