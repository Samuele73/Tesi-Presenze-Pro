package com.tesi.presenzepro.user.dto;

public record LoginRequestDto (
        String email,
        String password
){ }
