package com.tesi.presenzepro.calendar.model;

public enum CalendarEntryType {
    WORKING_DAY,
    REQUEST,
    WORKING_TRIP,
    AVAILABILITY
}
