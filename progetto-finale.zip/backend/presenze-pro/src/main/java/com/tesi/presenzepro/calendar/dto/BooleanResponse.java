package com.tesi.presenzepro.calendar.dto;

public record BooleanResponse(
        Boolean resp
) {
}
