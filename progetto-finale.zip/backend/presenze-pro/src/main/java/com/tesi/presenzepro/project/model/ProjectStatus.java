package com.tesi.presenzepro.project.model;

public enum ProjectStatus {
    CREATED,
    IN_PROGRESS,
    COMPLETED
}
