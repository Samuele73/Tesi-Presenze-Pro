package com.tesi.presenzepro.calendar.model;

public enum HoursType {
    LEAVE,
    PERMIT
}
