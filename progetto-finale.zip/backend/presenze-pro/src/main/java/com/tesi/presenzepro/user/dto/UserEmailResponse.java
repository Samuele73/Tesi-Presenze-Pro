package com.tesi.presenzepro.user.dto;

public record UserEmailResponse(
        String email
) {
}
