package com.tesi.presenzepro.project.dto;

public record ProjectIdResponse(
        String id
) {
}
