package com.tesi.presenzepro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PresenzeProApplicationTests {

	@Test
	void contextLoads() {
	}

}
